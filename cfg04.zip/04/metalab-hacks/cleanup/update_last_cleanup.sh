#!/bin/bash

date +"%Y-%m-%dT%H:%M:%S" > /home/homeassistant/.homeassistant/metalab-hacks/cleanup/last_cleanup.txt

