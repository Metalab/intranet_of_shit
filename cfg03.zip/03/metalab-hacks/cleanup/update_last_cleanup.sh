#!/bin/bash

date +"%Y-%m-%dT%H:%M:%S" > /home/homeassistant/last_cleanup.txt

